//
//  GameCenterHelper.swift
//  OpenProf
//
//  Created by Adam HAISSOUBI-VOGIER on 09/04/2021.
//

import UIKit
import GameKit

class PeerToPeerFight: NSObject{

}
