//
//  Player.swift
//  OpenProf
//
//  Created by Adam HAISSOUBI-VOGIER on 10/04/2021.
//

import Foundation

struct Player: Codable {
    var name: String
    //var status: PlayerStatus = .idle
    var life: Float = 1.0
}
